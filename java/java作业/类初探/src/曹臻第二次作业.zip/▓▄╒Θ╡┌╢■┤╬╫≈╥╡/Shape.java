public abstract class Shape
{
    double Area, Girth;
    abstract void  getArea();
    abstract void  getGirth();
}