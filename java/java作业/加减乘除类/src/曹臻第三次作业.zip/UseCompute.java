public class UseCompute {
    public static void useCom(Compute com, int one , int two)
    {
        System.out.println("计算结果为:"+com.computer(one,two));
    }
}
