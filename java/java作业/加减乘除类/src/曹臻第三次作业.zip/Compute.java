public interface Compute {
    public int computer(int n, int m);
}

