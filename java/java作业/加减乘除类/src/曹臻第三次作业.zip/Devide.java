public class Devide implements Compute {
    public  int computer(int n, int m)
    {
        if(m!=0) {
            return n / m;
        }
        else return 0;
    }
}
