public class Multiplicate implements Compute {
    public  int computer(int n, int m)
    {
        return n*m;
    }
}
